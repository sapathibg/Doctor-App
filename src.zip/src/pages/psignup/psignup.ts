import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { PloginPage } from '../plogin/plogin';

/**
 * Generated class for the PsignupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-psignup',
  templateUrl: 'psignup.html',
})
export class PsignupPage {
  nextPage = PloginPage;
 
 // Define FormBuilder /model properties
 public form                   : FormGroup;
 public firstName              : any;
 public technologyName         : any;
 public Email                  : any;
 public Password               : any;
 public Pnumber                : any;
 public Adharno                : any;
 public Gender                 : any;
 public Address                : any;


   // Flag to be used for checking whether we are adding/editing an entry
   public isEdited               : boolean = false;
   // Flag to hide the form upon successful completion of remote operation
   public hideForm               : boolean = false;
   // Property to help ste the page title
   public pageTitle              : string;
   // Property to store the recordID for when an existing entry is being edited
   public recordID               : any      = null;
   private baseURI               : string  = "http://localhost/ionic-php-mysql/";

   // Initialise module classes
   constructor(public navCtrl    : NavController,
               public http       : Http,
               public NP         : NavParams,
               public fb         : FormBuilder,
               public toastCtrl  : ToastController)
   {

      // Create form builder validation rules
      this.form = fb.group({
        "firstname"               : ["", Validators.required],
         "name"                   : ["", Validators.required],
         "email"                  : [null, Validators.compose([Validators.required, Validators.minLength(5), Validators.pattern("[^ @]*@[^ @]*"), Validators.maxLength(20)])],
         "password"               : [null, Validators.compose([Validators.required, Validators.minLength(6) ])],
         "pnumber"                : [null, Validators.compose([Validators.required,Validators.minLength(10), Validators.maxLength(10)])],
         "adharno"                : [null, Validators.compose([Validators.required,Validators.minLength(12), Validators.maxLength(12)])],
         "gender"                 : ["", Validators.required],
         "address"                : ["", Validators.required]
      });
   }



   // Determine whether we adding or editing a record
   // based on any supplied navigation parameters




   // Assign the navigation retrieved data to properties
   // used as models on the page's HTML form
   selectEntry(item)
   {
      this.firstName           = item.firstname;
      this.technologyName      = item.name;
      this.Email               = item.email;
      this.Password            = item.password;
      this.Pnumber             = item.pnumber;
      this.Adharno             = item.adharno;
      this.Gender              = item.gender;
      this.Address             = item.address;
      this.recordID            = item.id;
   }



   // Save a new record that has been added to the page's HTML form
   // Use angular's http post method to submit the record data
   // to our remote PHP script (note the body variable we have created which
   // supplies a variable of key with a value of create followed by the key/value pairs
   // for the record data
   createEntry(firstname,name,email,password,pnumber,adharno,gender, address)
   {
      let body     : string   = "key=create&firstname=" + firstname + "&name=" + name +"&email=" + email + "&password=" + password + "&pnumber=" + pnumber +"&adharno=" + adharno + "&gender="+ gender + "&address=" + address,
          type     : string   = "application/x-www-form-urlencoded; charset=UTF-8",
          headers  : any      = new Headers({ 'Content-Type': type}),
          options  : any      = new RequestOptions({ headers: headers }),
          url      : any      = this.baseURI + "psignup-manage-data.php";

      this.http.post(url, body, options)
      .subscribe((data) =>
      {
         // If the request was successful notify the user
         if(data.status === 200)
         {
            this.hideForm   = true;
            this.sendNotification(`Congratulations the technology: ${firstname} was successfully added`);
         }
         // Otherwise let 'em know anyway
         else
         {
            this.sendNotification('Something went wrong!');
         }
      });
   }



   // Update an existing record that has been edited in the page's HTML form
   // Use angular's http post method to submit the record data
   // to our remote PHP script (note the body variable we have created which
   // supplies a variable of key with a value of update followed by the key/value pairs
   // for the record data
  


   // Remove an existing record that has been selected in the page's HTML form
   // Use angular's http post method to submit the record data
   // to our remote PHP script (note the body variable we have created which
   // supplies a variable of key with a value of delete followed by the key/value pairs
   // for the record ID we want to remove from the remote database
  



   // Handle data submitted from the page's HTML form
   // Determine whether we are adding a new record or amending an
   // existing record
   saveEntry()
   {
      var   firstname          : string = this.form.controls["firstname"].value;
      var    name              : string = this.form.controls["name"].value;
      var    email             : string = this.form.controls["email"].value;
      var    password          : string = this.form.controls["password"].value;
      var    pnumber           : string = this.form.controls["pnumber"].value;
      var    adharno           : string = this.form.controls["adharno"].value;
      var    gender            : string = this.form.controls["gender"].value;
      var    address           : string = this.form.controls["address"].value;

     
     this.createEntry(firstname, name,email,password,pnumber, adharno,gender, address);
  
   }



   // Clear values in the page's HTML form fields
   resetFields() : void
   {
      this.technologyName  = "";
      this.Address         = "";
   }



   // Manage notifying the user of the outcome
   // of remote operations
   sendNotification(message)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
   }



}