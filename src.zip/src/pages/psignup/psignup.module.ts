import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PsignupPage } from './psignup';

@NgModule({
  declarations: [
    PsignupPage,
  ],
  imports: [
    IonicPageModule.forChild(PsignupPage),
  ],
  exports: [
    PsignupPage
  ]
})
export class PsignupPageModule {}
