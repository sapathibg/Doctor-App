import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
/**
 * Generated class for the DoctorDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-doctor-details',
  templateUrl: 'doctor-details.html',
})
export class DoctorDetailsPage {
// Define FormBuilder /model properties
public form                   : FormGroup;
public fullName               : any;
public Category               : any;
public Specilist              : any;
public Experience             : any;
public Qualification          : any;
public Pnumber                : any;
public Locality               : any;
public Address                : any;


  // Flag to be used for checking whether we are adding/editing an entry
  public isEdited               : boolean = false;
  // Flag to hide the form upon successful completion of remote operation
  public hideForm               : boolean = false;
  // Property to help ste the page title
  public pageTitle              : string;
  // Property to store the recordID for when an existing entry is being edited
  public recordID               : any      = null;
  private baseURI               : string  = "http://localhost/ionic-php-mysql/";

  // Initialise module classes
  constructor(public navCtrl    : NavController,
              public http       : Http,
              public NP         : NavParams,
              public fb         : FormBuilder,
              public toastCtrl  : ToastController)
  {

     // Create form builder validation rules
     this.form = fb.group({
       "fullname"                : ["", Validators.required],
        "category"               : ["", Validators.required],
        "specilist"              : ["", Validators.required],
        "experience"             : ["", Validators.required],
        "qualification"          : ["", Validators.required],
        "pnumber"                : ["", Validators.required],
        "locality"               : ["", Validators.required],
        "address"                : ["", Validators.required]
     });
  }



  // Determine whether we adding or editing a record
  // based on any supplied navigation parameters




  // Assign the navigation retrieved data to properties
  // used as models on the page's HTML form
  selectEntry(item)
  {
     this.fullName            = item.fullname;
     this.Category            = item.category;
     this.Specilist           = item.specilist;
     this.Experience          = item.experience;
     this.Qualification       = item.qualification;
     this.Pnumber             = item.pnumber;
     this.Locality            = item.locality;
     this.Address             = item.address;
     this.recordID            = item.id;
  }



  // Save a new record that has been added to the page's HTML form
  // Use angular's http post method to submit the record data
  // to our remote PHP script (note the body variable we have created which
  // supplies a variable of key with a value of create followed by the key/value pairs
  // for the record data
  createEntry(fullname,category,specilist,experience,qualification,pnumber,locality, address)
  {
     let body     : string   = "key=create&fullname=" + fullname + "&category=" + category +"&specilist=" + specilist + "&experience=" + experience +"&qualification=" + qualification + "&pnumber=" + pnumber + "&locality="+ locality + "&address=" + address,
         type     : string   = "application/x-www-form-urlencoded; charset=UTF-8",
         headers  : any      = new Headers({ 'Content-Type': type}),
         options  : any      = new RequestOptions({ headers: headers }),
         url      : any      = this.baseURI + "doctor_details-manage-data.php";

     this.http.post(url, body, options)
     .subscribe((data) =>
     {
        // If the request was successful notify the user
        if(data.status === 200)
        {
           this.hideForm   = true;
           this.sendNotification(`Congratulations the Account: ${fullname} was successfully added`);
        }
        // Otherwise let 'em know anyway
        else
        {
           this.sendNotification('Something went wrong!');
        }
     });
  }



  // Update an existing record that has been edited in the page's HTML form
  // Use angular's http post method to submit the record data
  // to our remote PHP script (note the body variable we have created which
  // supplies a variable of key with a value of update followed by the key/value pairs
  // for the record data
 


  // Remove an existing record that has been selected in the page's HTML form
  // Use angular's http post method to submit the record data
  // to our remote PHP script (note the body variable we have created which
  // supplies a variable of key with a value of delete followed by the key/value pairs
  // for the record ID we want to remove from the remote database
 



  // Handle data submitted from the page's HTML form
  // Determine whether we are adding a new record or amending an
  // existing record
  saveEntry()
  {
     var   fullname           : string = this.form.controls["fullname"].value;
     var    category          : string = this.form.controls["category"].value;
     var    specilist         : string = this.form.controls["specilist"].value;
     var    experience        : string = this.form.controls["experience"].value;
     var    qualification     : string = this.form.controls["qualification"].value;
     var    pnumber           : string = this.form.controls["pnumber"].value;
     var    locality            : string = this.form.controls["locality"].value;
     var    address           : string = this.form.controls["address"].value;

    
    this.createEntry(fullname, category,specilist,experience,qualification,pnumber, locality, address);
 
  }



  // Clear values in the page's HTML form fields
  resetFields() : void
  {
     this.Category  = "";
     this.Address         = "";
  }



  // Manage notifying the user of the outcome
  // of remote operations
  sendNotification(message)  : void
  {
     let notification = this.toastCtrl.create({
         message       : message,
         duration      : 3000
     });
     notification.present();
  }



}