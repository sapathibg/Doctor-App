import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DsignupPage } from './dsignup';

@NgModule({
  declarations: [
    DsignupPage,
  ],
  imports: [
    IonicPageModule.forChild(DsignupPage),
  ],
})
export class DsignupPageModule {}
