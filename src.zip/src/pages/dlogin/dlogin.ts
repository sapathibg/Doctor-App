import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { DsignupPage } from '../dsignup/dsignup';
import { DoctorDetailsPage } from '../doctor-details/doctor-details';



/**
 * Generated class for the DloginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-dlogin',
  templateUrl: 'dlogin.html',
})
export class DloginPage {
  doctordetails = DoctorDetailsPage;
  nextPage=DsignupPage;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DloginPage');
  }

}
