import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { MyApp } from './app.component';


import { PsignupPage } from '../pages/psignup/psignup';
import { PloginPage } from '../pages/plogin/plogin';
import { DsignupPage } from '../pages/dsignup/dsignup';
import { DloginPage } from '../pages/dlogin/dlogin';
import { IntroPage } from '../pages/intro/intro';
import { DoctorDetailsPage } from '../pages/doctor-details/doctor-details';
import { PatientDetailsPage } from '../pages/patient-details/patient-details';


@NgModule({
  declarations: [
    MyApp,
    PsignupPage,
    PloginPage,
    DsignupPage,
    DloginPage,
    IntroPage,
    DoctorDetailsPage,
    PatientDetailsPage,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    PsignupPage,
    PloginPage,
    DsignupPage,
    DloginPage,
    IntroPage,
    DoctorDetailsPage,
    PatientDetailsPage,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}